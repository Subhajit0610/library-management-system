<script type="text/javascript">    
    
</script>

<?php echo $__env->yieldContent('custom_bottom_script'); ?><?php /**PATH C:\xampp\htdocs\LMS-IN-LARAVEL\resources\views/common/script_bottom.blade.php ENDPATH**/ ?>