<div class="alert alert-<%= obj.type %> alert-dismissable center-block">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>    
    <%= obj.message %>
</div><?php /**PATH C:\xampp\htdocs\LMS-IN-LARAVEL\resources\views/underscore/alert_box.blade.php ENDPATH**/ ?>