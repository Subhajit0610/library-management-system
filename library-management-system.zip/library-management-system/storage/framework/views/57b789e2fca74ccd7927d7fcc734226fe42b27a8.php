<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container">
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
				<i class="icon-reorder shaded"></i>
			

			</a>
			  <a class="brand" href="<?php echo e(URL::route('home')); ?>" style="color:#fff">CHMSC LIBRARY SYSTEM </a> <marquee class="brand" style="color:#fff"  behavior="" direction="">WELCOME TO CHMSC LIBRARY MANAGEMENT SYSTEM</marquee>

			 
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\LMS-IN-LARAVEL\resources\views/account/navigation_top.blade.php ENDPATH**/ ?>