;<div class="footer" style="background-color: #00cc00;">
	<div class="container">
		<center><b class="copyright" style="color: white;">&copy; <?php echo e(date('Y')); ?> - Library Management System!...All rights reserved. </b> </center>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/layout/template_footer.blade.php ENDPATH**/ ?>