<div class="footer">
	<div class="container">
		<b class="copyright">&copy; <?php echo e(date('Y')); ?> - Online Library Management System </b> All rights reserved.
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\LMS-IN-LARAVEL\resources\views/account/navigation_bottom.blade.php ENDPATH**/ ?>