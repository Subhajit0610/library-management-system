<script type="text/javascript">    
    
</script>

<?php echo $__env->yieldContent('custom_bottom_script'); ?><?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/common/script_bottom.blade.php ENDPATH**/ ?>