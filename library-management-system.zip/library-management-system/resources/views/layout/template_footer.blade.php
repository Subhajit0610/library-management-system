;<div class="footer" style="background-color: #00cc00;">
	<div class="container">
		<center><b class="copyright" style="color: white;">&copy; {{ date('Y') }} - Library Management System!...All rights reserved. </b> </center>
	</div>
</div>
